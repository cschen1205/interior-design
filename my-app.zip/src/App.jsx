/* eslint-disable react/no-unknown-property */
/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, OrbitControls, useGLTF, Clone } from "@react-three/drei";
import { Suspense, useState, useRef } from "react";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { v4 as uuidv4 } from "uuid";
import { motion } from "framer-motion";
import * as THREE from "three";

const models = [
  { id: "1", name: "Model A", path: "/models/modelA.glb" },
  { id: "2", name: "Model B", path: "/models/modelB.glb" },
];

function Model({ model, position, onMove }) {
  const { scene } = useGLTF(model.path);
  return (
      <Clone object={scene} position={position} />
  );
}

function DroppableScene() {
  const [placedModels, setPlacedModels] = useState([]);
  const { camera, raycaster, mouse, scene } = useThree();

  const handleDrop = (model, event) => {
    let dropPosition = [0, 0, 0];
    console.log("handleDrop", event);

    if (event) {
      event.stopPropagation();
      raycaster.setFromCamera(mouse, camera);

      const intersects = raycaster.intersectObjects(scene.children, true);
      if (intersects.length > 0) {
        dropPosition = intersects[0].point.toArray();
      }
      console.log("Drop Position", dropPosition);
    }

    if (model) {
      const newModel = {
        ...model,
        id: uuidv4(),
        position: dropPosition,
      };
      setPlacedModels((prev) => [...prev, newModel]);
    }
  };


  const sceneRef = useRef();
  const [{ isOver }, drop] = useDrop(() => ({
    accept: ["MODEL", "PLACED_MODEL"],
    drop: (item, monitor) => {
      console.log("Drop", item, item.type, monitor);
        const offset = monitor.getSourceClientOffset();
        handleDrop(item.model, offset);
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }));

  console.log("DroppableScene", placedModels);

  return (
    <div ref={drop} className="relative w-full h-screen">
      <Canvas camera={{ position: [0, 5, 10], fov: 50 }}>
        <OrbitControls />
        <ambientLight intensity={0.5} />
        <Environment preset="city" />
        <mesh
            ref={sceneRef}
            rotation={[-Math.PI / 2, 0, 0]}
            position={[0, -0.5, 0]}
            onPointerDown={(e) => handleDrop(null, e)}
          >
            <planeGeometry args={[10, 10]} />
            <meshStandardMaterial color="lightgray" />
          </mesh>
        <Suspense fallback={null}>
          {/* Floor */}
          {placedModels.map((m) => (
            <Model key={m.id} model={m} position={m.position} />
          ))}
        </Suspense>
      </Canvas>
    </div>
  );
}

function ModelItem({ model }) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: "MODEL",
    item: { model },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));
  console.log("ModelItem", model);

  return (
    <motion.div
      ref={drag}
      className="p-2 bg-white shadow-md rounded-md cursor-pointer"
      whileHover={{ scale: 1.1 }}
    >
      <img src="/thumbnail.png" alt={model.name} className="w-20 h-20" />
      <p className="text-center">{model.name}</p>
    </motion.div>
  );
}

function App() {
  

  // const addModel = () => {
  //   console.log("place model: ", placedModels)
  //   setPlacedModels((prev) => [
  //     ...prev,
  //     {
  //       ...models[0],
  //       id: uuidv4(),
  //       position: [Math.random() * 5, 0, Math.random() * 5],
  //     },
  //   ]);
  // };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="flex h-screen">
        {/* Left Panel: Model Selection */}
        <div className="w-1/4 p-4 bg-gray-100">
          <h2 className="text-lg font-bold mb-4">Models</h2>
          <div className="grid grid-cols-2 gap-4">
            {models.map((model) => (
              <ModelItem key={model.id} model={model} />
            ))}
          </div>
        </div>


        {/* Right Panel: 3D Scene */}
        <div className="w-3/4">
        {/* <button onClick={addModel} style={{ position: "absolute", zIndex: 1 }}>
          Add Model
        </button> */}
          <DroppableScene />
        </div>
      </div>
    </DndProvider>
  );
}

export default App;
